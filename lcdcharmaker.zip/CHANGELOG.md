Changelog LCD Charmaker

20170227 v1.65
* NEW: Published on Github

